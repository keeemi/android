package com.example.catapi;

public class User {
/*[{
        "id":"ebv",
                "url":"https://cdn2.thecatapi.com/images/ebv.jpg",
                "width":176,"height":540,
                "breeds":[],
        "favourite":{}
    }]*/

    public String id;
    public String url;
    public int width;
    public int height;
    public String breeds;
    public String favourite;


}
