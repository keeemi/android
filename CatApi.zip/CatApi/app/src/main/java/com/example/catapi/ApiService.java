package com.example.catapi;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {
    @GET("images/search")
    Call<User[]> getUser(@Query("limit") int limit);
    // Inne metody dla różnych żądań HTTP
}

