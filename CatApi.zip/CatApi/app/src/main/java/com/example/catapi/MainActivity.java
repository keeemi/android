package com.example.catapi;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_INTERNET_PERMISSION = 1;
    private ApiService apiService;
    User[] user;
    TextView TVurl;
    TextView TVwidth;
    TextView TVheight;
    Button bLeft;
    Button bRight;
    ImageView IVobrazek;
    LinearLayout layout;

    private int index = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        apiService = ApiClient.getRetrofitInstance().create(ApiService.class);

        TVurl = findViewById(R.id.textViewUserURL);
        TVwidth = findViewById(R.id.textViewUserWidth);
        TVheight = findViewById(R.id.textViewUserHeight);
        bLeft = findViewById(R.id.buttonLeft);
        bRight = findViewById(R.id.buttonRight);
        IVobrazek = findViewById(R.id.imageView);
        layout = findViewById(R.id.linearLayout);



        bLeft.setOnClickListener(e -> {

            if (index>0){
                index--;
            }
            else{
                index=user.length-1;


            }
            setElements();
        });


        bRight.setOnClickListener(e -> {
            if (index >= user.length - 1) {

                index=0;
            }
            else{
                index++;
            }

            setElements();
        });

        /*public static Drawable LoadImageFromWebOperations(String url){
            try{
                InputStream is = (InputStream) new URL(url).getContent();
                Drawable d = Drawable.createFromStream(is, "src name");
                return d;
            } catch (Exception e){
                return null;
            }
        }*/


        // Przykład wywołania API (GET request)
        Call<User[]> call = apiService.getUser(5);
        call.enqueue(new Callback<User[]>() {
            @Override
            public void onResponse(Call<User[]> call, Response<User[]> response) {
                if (response.isSuccessful()) {
                    user = response.body();
                    // Obsługa danych użytkownika
                    int a = 0;

                    setElements();



                } else {
                    // Obsługa błędów
                }
            }

            @Override
            public void onFailure(Call<User[]> call, Throwable t) {
                // Obsługa błędów komunikacji
            }
        });
        action();
    }

    private void action() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.INTERNET)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.INTERNET}, REQUEST_INTERNET_PERMISSION);
            return;
        }
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_INTERNET_PERMISSION && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(getApplicationContext(), "Przyznano uprawnienia", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(getApplicationContext(), "Nie przyznano uprawnień", Toast.LENGTH_LONG).show();
        }
    }

    private void setElements() {
        TVurl.setText(user[index].url);
        TVwidth.setText(user[index].width + "");
        TVheight.setText(user[index].height + "");
        //IVobrazek.setImageBitmap();
        DownloadImageFromInternet getImage = new DownloadImageFromInternet(IVobrazek);
        getImage.execute(user[index].url);
        //IVobrazek.setImageBitmap(R.drawable.ic_launcher_background.xml.user[index].url);
        View wyglad;
        wyglad = getLayoutInflater().inflate(R.layout.zdjeciepodejsciedrugie,layout,false);

    }

    class DownloadImageFromInternet extends AsyncTask<String, Void, Bitmap> {
        ImageView imageView;

        public DownloadImageFromInternet(ImageView imageView) {
            this.imageView = imageView;
            //Toast.makeText(getApplicationContext(), "Please wait, it may take a few minute...", Toast.LENGTH_SHORT).show();
        }

        protected Bitmap doInBackground(String... urls) {
            String imageURL = urls[0];
            Bitmap bimage = null;
            try {
                InputStream in = new java.net.URL(user[index].url).openStream();
                bimage = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error Message", e.getMessage());
                e.printStackTrace();
            }
            return bimage;
        }

        protected void onPostExecute(Bitmap result) {
            imageView.setImageBitmap(result);
        }
    }
}