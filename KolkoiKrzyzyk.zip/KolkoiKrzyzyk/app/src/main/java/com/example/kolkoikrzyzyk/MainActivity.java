package com.example.kolkoikrzyzyk;

import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView goraLewe;
    TextView goraSrodkowe;
    TextView goraPrawe;

    TextView srodekLewe;
    TextView srodekSrodkowe;
    TextView srodekPrawe;

    TextView dolLewe;
    TextView dolSrodkowe;
    TextView dolPrawe;
    boolean kolejX = true;

    TextView informacja;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        goraLewe = findViewById(R.id.poleGoraLewe);
        goraSrodkowe = findViewById(R.id.poleGoraSrodkowe);
        goraPrawe = findViewById(R.id.poleGoraPrawe);

        srodekLewe = findViewById(R.id.poleSrodekLewe);
        srodekSrodkowe = findViewById(R.id.poleSrodekSrodkowe);
        srodekPrawe = findViewById(R.id.poleSrodekPrawe);

        dolLewe = findViewById(R.id.poleDolLewe);
        dolSrodkowe = findViewById(R.id.poleDolSrodkowe);
        dolPrawe = findViewById(R.id.poleDolPrawe);

        informacja = findViewById(R.id.textViewInformacja);


        goraLewe.setOnClickListener(e ->{
            klikniecie(goraLewe);
        });

        goraSrodkowe.setOnClickListener(e ->{
            klikniecie(goraSrodkowe);
        });

        goraPrawe.setOnClickListener(e ->{
            klikniecie(goraPrawe);
        });

        srodekLewe.setOnClickListener(e -> {
            klikniecie(srodekLewe);
        });

        srodekSrodkowe.setOnClickListener(e -> {
            klikniecie(srodekSrodkowe);
        });

        srodekPrawe.setOnClickListener(e -> {
            klikniecie(srodekPrawe);
        });

        dolLewe.setOnClickListener(e -> {
            klikniecie(dolLewe);
        });

        dolSrodkowe.setOnClickListener(e -> {
            klikniecie(dolSrodkowe);
        });

        dolPrawe.setOnClickListener(e ->{
            klikniecie(dolPrawe);
        });




    }

    private void wynik(TextView przycisk){

    }

    private void klikniecie(TextView przycisk) {
        if (przycisk.getText()=="X" || przycisk.getText()=="o"){

        }
        else {
            if (kolejX == true) {
                przycisk.setText("X");
                kolejX = false;
            } else {
                przycisk.setText("o");
                kolejX = true;
            }
        }

        if (goraLewe.getText()=="X" && goraSrodkowe.getText()=="X" && goraPrawe.getText()=="X"){
            Toast.makeText(getApplicationContext(), "X wygrywa", Toast.LENGTH_LONG).show();
            informacja.setText(informacja.getText()+"X wygrywa\n");

            goraLewe.setText("");
            goraSrodkowe.setText("");
            goraPrawe.setText("");
            srodekLewe.setText("");
            srodekSrodkowe.setText("");
            srodekPrawe.setText("");
            dolLewe.setText("");
            dolSrodkowe.setText("");
            dolPrawe.setText("");
        }
        if (goraLewe.getText()=="o" && goraSrodkowe.getText()=="o" && goraPrawe.getText()=="o"){
            Toast.makeText(getApplicationContext(), "o wygrywa", Toast.LENGTH_LONG).show();
            informacja.setText(informacja.getText()+"o wygrywa\n");

            goraLewe.setText("");
            goraSrodkowe.setText("");
            goraPrawe.setText("");
            srodekLewe.setText("");
            srodekSrodkowe.setText("");
            srodekPrawe.setText("");
            dolLewe.setText("");
            dolSrodkowe.setText("");
            dolPrawe.setText("");
        }

        if (srodekLewe.getText()=="X" && srodekSrodkowe.getText()=="X" && srodekPrawe.getText()=="X"){
            Toast.makeText(getApplicationContext(), "X wygrywa", Toast.LENGTH_LONG).show();
            informacja.setText(informacja.getText()+"X wygrywa\n");

            goraLewe.setText("");
            goraSrodkowe.setText("");
            goraPrawe.setText("");
            srodekLewe.setText("");
            srodekSrodkowe.setText("");
            srodekPrawe.setText("");
            dolLewe.setText("");
            dolSrodkowe.setText("");
            dolPrawe.setText("");
        }
        if (srodekLewe.getText()=="o" && srodekSrodkowe.getText()=="o" && srodekPrawe.getText()=="o"){
            Toast.makeText(getApplicationContext(), "o wygrywa", Toast.LENGTH_LONG).show();
            informacja.setText(informacja.getText()+"o wygrywa\n");

            goraLewe.setText("");
            goraSrodkowe.setText("");
            goraPrawe.setText("");
            srodekLewe.setText("");
            srodekSrodkowe.setText("");
            srodekPrawe.setText("");
            dolLewe.setText("");
            dolSrodkowe.setText("");
            dolPrawe.setText("");
        }

        if (dolLewe.getText()=="X" && dolSrodkowe.getText()=="X" && dolPrawe.getText()=="X"){
            Toast.makeText(getApplicationContext(), "X wygrywa", Toast.LENGTH_LONG).show();
            informacja.setText(informacja.getText()+"X wygrywa\n");

            goraLewe.setText("");
            goraSrodkowe.setText("");
            goraPrawe.setText("");
            srodekLewe.setText("");
            srodekSrodkowe.setText("");
            srodekPrawe.setText("");
            dolLewe.setText("");
            dolSrodkowe.setText("");
            dolPrawe.setText("");
        }
        if (dolLewe.getText()=="o" && dolSrodkowe.getText()=="o" && dolPrawe.getText()=="o"){
            Toast.makeText(getApplicationContext(), "o wygrywa", Toast.LENGTH_LONG).show();
            informacja.setText(informacja.getText()+"o wygrywa\n");

            goraLewe.setText("");
            goraSrodkowe.setText("");
            goraPrawe.setText("");
            srodekLewe.setText("");
            srodekSrodkowe.setText("");
            srodekPrawe.setText("");
            dolLewe.setText("");
            dolSrodkowe.setText("");
            dolPrawe.setText("");
        }

        if (goraLewe.getText()=="X" && srodekLewe.getText()=="X" && dolLewe.getText()=="X"){
            Toast.makeText(getApplicationContext(), "X wygrywa", Toast.LENGTH_LONG).show();
            informacja.setText(informacja.getText()+"X wygrywa\n");

            goraLewe.setText("");
            goraSrodkowe.setText("");
            goraPrawe.setText("");
            srodekLewe.setText("");
            srodekSrodkowe.setText("");
            srodekPrawe.setText("");
            dolLewe.setText("");
            dolSrodkowe.setText("");
            dolPrawe.setText("");
        }
        if (goraLewe.getText()=="o" && srodekLewe.getText()=="o" && dolLewe.getText()=="o"){
            Toast.makeText(getApplicationContext(), "o wygrywa", Toast.LENGTH_LONG).show();
            informacja.setText(informacja.getText()+"o wygrywa\n");

            goraLewe.setText("");
            goraSrodkowe.setText("");
            goraPrawe.setText("");
            srodekLewe.setText("");
            srodekSrodkowe.setText("");
            srodekPrawe.setText("");
            dolLewe.setText("");
            dolSrodkowe.setText("");
            dolPrawe.setText("");
        }

        if (goraSrodkowe.getText()=="X" && srodekSrodkowe.getText()=="X" && dolSrodkowe.getText()=="X"){
            Toast.makeText(getApplicationContext(), "X wygrywa", Toast.LENGTH_LONG).show();
            informacja.setText(informacja.getText()+"X wygrywa\n");

            goraLewe.setText("");
            goraSrodkowe.setText("");
            goraPrawe.setText("");
            srodekLewe.setText("");
            srodekSrodkowe.setText("");
            srodekPrawe.setText("");
            dolLewe.setText("");
            dolSrodkowe.setText("");
            dolPrawe.setText("");
        }
        if (goraSrodkowe.getText()=="o" && srodekSrodkowe.getText()=="o" && dolSrodkowe.getText()=="o"){
            Toast.makeText(getApplicationContext(), "o wygrywa", Toast.LENGTH_LONG).show();
            informacja.setText(informacja.getText()+"o wygrywa\n");

            goraLewe.setText("");
            goraSrodkowe.setText("");
            goraPrawe.setText("");
            srodekLewe.setText("");
            srodekSrodkowe.setText("");
            srodekPrawe.setText("");
            dolLewe.setText("");
            dolSrodkowe.setText("");
            dolPrawe.setText("");
        }

        if (goraPrawe.getText()=="X" && srodekPrawe.getText()=="X" && dolPrawe.getText()=="X"){
            Toast.makeText(getApplicationContext(), "X wygrywa", Toast.LENGTH_LONG).show();
            informacja.setText(informacja.getText()+"X wygrywa\n");

            goraLewe.setText("");
            goraSrodkowe.setText("");
            goraPrawe.setText("");
            srodekLewe.setText("");
            srodekSrodkowe.setText("");
            srodekPrawe.setText("");
            dolLewe.setText("");
            dolSrodkowe.setText("");
            dolPrawe.setText("");
        }
        if (goraPrawe.getText()=="o" && srodekPrawe.getText()=="o" && dolPrawe.getText()=="o"){
            Toast.makeText(getApplicationContext(), "o wygrywa", Toast.LENGTH_LONG).show();
            informacja.setText(informacja.getText()+"o wygrywa\n");

            goraLewe.setText("");
            goraSrodkowe.setText("");
            goraPrawe.setText("");
            srodekLewe.setText("");
            srodekSrodkowe.setText("");
            srodekPrawe.setText("");
            dolLewe.setText("");
            dolSrodkowe.setText("");
            dolPrawe.setText("");
        }

        if (goraLewe.getText()=="X" && srodekSrodkowe.getText()=="X" && dolPrawe.getText()=="X"){
            Toast.makeText(getApplicationContext(), "X wygrywa", Toast.LENGTH_LONG).show();
            informacja.setText(informacja.getText()+"X wygrywa\n");

            goraLewe.setText("");
            goraSrodkowe.setText("");
            goraPrawe.setText("");
            srodekLewe.setText("");
            srodekSrodkowe.setText("");
            srodekPrawe.setText("");
            dolLewe.setText("");
            dolSrodkowe.setText("");
            dolPrawe.setText("");
        }
        if (goraLewe.getText()=="o" && srodekSrodkowe.getText()=="o" && dolPrawe.getText()=="o"){
            Toast.makeText(getApplicationContext(), "o wygrywa", Toast.LENGTH_LONG).show();
            informacja.setText(informacja.getText()+"o wygrywa\n");

            goraLewe.setText("");
            goraSrodkowe.setText("");
            goraPrawe.setText("");
            srodekLewe.setText("");
            srodekSrodkowe.setText("");
            srodekPrawe.setText("");
            dolLewe.setText("");
            dolSrodkowe.setText("");
            dolPrawe.setText("");
        }

        if (goraPrawe.getText()=="X" && srodekSrodkowe.getText()=="X" && dolLewe.getText()=="X"){
            Toast.makeText(getApplicationContext(), "X wygrywa", Toast.LENGTH_LONG).show();
            informacja.setText(informacja.getText()+"X wygrywa\n");

            goraLewe.setText("");
            goraSrodkowe.setText("");
            goraPrawe.setText("");
            srodekLewe.setText("");
            srodekSrodkowe.setText("");
            srodekPrawe.setText("");
            dolLewe.setText("");
            dolSrodkowe.setText("");
            dolPrawe.setText("");
        }
        if (goraPrawe.getText()=="o" && srodekSrodkowe.getText()=="o" && dolLewe.getText()=="o"){
            Toast.makeText(getApplicationContext(), "o wygrywa", Toast.LENGTH_LONG).show();
            informacja.setText(informacja.getText()+"o wygrywa\n");

            goraLewe.setText("");
            goraSrodkowe.setText("");
            goraPrawe.setText("");
            srodekLewe.setText("");
            srodekSrodkowe.setText("");
            srodekPrawe.setText("");
            dolLewe.setText("");
            dolSrodkowe.setText("");
            dolPrawe.setText("");
        }


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.VANILLA_ICE_CREAM) {
            if (!goraLewe.getText().isEmpty() && !goraSrodkowe.getText().isEmpty() && !goraLewe.getText().isEmpty()
            && !srodekLewe.getText().isEmpty() && !srodekSrodkowe.getText().isEmpty() && !srodekPrawe.getText().isEmpty()
            && !dolLewe.getText().isEmpty() && !dolSrodkowe.getText().isEmpty() && !dolPrawe.getText().isEmpty()) {
                informacja.setText(informacja.getText()+"Koniec gry. nikt nie wygral\n");

                goraLewe.setText("");
                goraSrodkowe.setText("");
                goraPrawe.setText("");
                srodekLewe.setText("");
                srodekSrodkowe.setText("");
                srodekPrawe.setText("");
                dolLewe.setText("");
                dolSrodkowe.setText("");
                dolPrawe.setText("");
            }

            /*if (goraLewe.getText()=="X" || goraLewe.getText()=="o" &&
                    goraSrodkowe.getText()=="X" || goraSrodkowe.getText()=="o" &
            goraPrawe.getText()=="X" || goraPrawe.getText()=="o" &
            srodekLewe.getText()=="X" || srodekLewe.getText()=="o" &
            srodekSrodkowe.getText()=="X" || srodekSrodkowe.getText()=="o" &
            srodekPrawe.getText()=="X" || srodekPrawe.getText()=="o" &
            dolLewe.getText()=="X" || dolLewe.getText()=="o" &
            dolSrodkowe.getText()=="X" || dolSrodkowe.getText()=="o" &
            dolPrawe.getText()=="X"|| dolPrawe.getText()=="o"){
                Toast.makeText(getApplicationContext(), "Koniec gry", Toast.LENGTH_LONG).show();
                informacja.setText(informacja.getText()+"Koniec gry");
            }*/
        }

    }

}