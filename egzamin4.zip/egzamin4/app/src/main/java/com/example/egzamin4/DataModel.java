package com.example.egzamin4;

public class DataModel {

   /* String name;
    String lastname;
    int telephoneNumber;

    public DataModel(String name,String lastname,int telephoneNumber) {
        this.name=name;
        this.lastname=lastname;
        this.telephoneNumber=telephoneNumber;

    }

    public String getName() {
        return name;
    }

    public String getLastname(){
        return lastname;
    }

    public int getTelephoneNumber(){
        return telephoneNumber;
    }*/

    String notatka;

    public DataModel(String notatka){
        this.notatka = notatka;
    }

    public String getNotatka(){
        return notatka;
    }




}