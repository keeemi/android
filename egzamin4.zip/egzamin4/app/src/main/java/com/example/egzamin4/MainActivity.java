package com.example.egzamin4;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button buttonDodaj;
    TextView editTextNowyElement;
    ArrayList<DataModel> data = new ArrayList<>();
    CustomAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        buttonDodaj = findViewById(R.id.buttonDodaj);
        editTextNowyElement = findViewById(R.id.editTextNowyElement);


        ListView listView = findViewById(R.id.listView);


        /*data.add(new DataModel("Jan","Kowalski",123456789));
        data.add(new DataModel("Beata","Nowak",987654321));*/
        data.add(new DataModel("Zakupy: chleb, masło, ser"));
        data.add(new DataModel("Do zrobienia: obiad, umyć podłogi"));
        data.add(new DataModel("weekend: kino, spacer z psem"));

        /*SpinnerAdapter adapter = new ArrayAdapter(this, R.layout.element_listy,  data);
        listView.setAdapter(adapter);*/

        adapter= new CustomAdapter(data,getApplicationContext());

        listView.setAdapter(adapter);

        buttonDodaj.setOnClickListener(e->{
            data.add(new DataModel(editTextNowyElement.getText().toString()));
            adapter= new CustomAdapter(data,getApplicationContext());
            listView.setAdapter(adapter);
        });



    }




}