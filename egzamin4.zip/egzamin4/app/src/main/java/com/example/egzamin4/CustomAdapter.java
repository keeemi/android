package com.example.egzamin4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapter extends ArrayAdapter<DataModel> implements View.OnClickListener{

    private ArrayList<DataModel> dataSet;
    Context mContext;

    @Override
    public void onClick(View v) {

    }

    // View lookup cache
    private static class ViewHolder {
        TextView txtName;

    }

    public CustomAdapter(ArrayList<DataModel> data, Context context) {
        super(context, R.layout.element_listy, data);
        this.dataSet = data;
        this.mContext=context;

    }



    private int lastPosition = -1;

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View List = convertView;
        if (List==null){
            List = LayoutInflater.from(mContext).inflate(R.layout.testowy_widok,parent,false);
        }
        // Get the data item for this position
        DataModel dataModel = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        TextView t = List.findViewById(R.id.textView213);
        /*t.setText("Imię: "+dataModel.getName()+", Nazwisko: "+dataModel.getLastname()+", Numer telefonu: "+ dataModel.getTelephoneNumber());*/
        t.setText(dataModel.getNotatka());

        // Return the completed view to render on screen
        return List;
    }
}
