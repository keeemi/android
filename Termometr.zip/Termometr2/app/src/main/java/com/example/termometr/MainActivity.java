package com.example.termometr;


import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity implements SensorEventListener{

    private SensorManager sensorManager;
    private SensorManager sensorManager2;
    private Sensor thermometer;
    private Sensor lightSensor;
    private TextView tempValues;
    private TextView lightValues;
    private TextView humidityValues;
    private Sensor humiditySensor;
    private SensorManager sensorManager3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        thermometer = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);
        tempValues = findViewById(R.id.temperatureValues);

        sensorManager2 = (SensorManager) getSystemService(SENSOR_SERVICE);
        lightSensor = sensorManager2.getDefaultSensor(Sensor.TYPE_LIGHT);
        lightValues = findViewById(R.id.lValues);

        sensorManager3 = (SensorManager) getSystemService(SENSOR_SERVICE);
        humiditySensor = sensorManager3.getDefaultSensor(Sensor.TYPE_RELATIVE_HUMIDITY);
        humidityValues = findViewById(R.id.humidValues);




        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    public final void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Do something here if sensor accuracy changes.
    }

    @Override
    public final void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() ==Sensor.TYPE_AMBIENT_TEMPERATURE) {
            float ambient_temperature = event.values[0];
            tempValues.setText("Temperatura:\n " + String.valueOf(ambient_temperature));
        }

        if (event.sensor.getType() ==Sensor.TYPE_LIGHT) {
            float light = event.values[0];
            lightValues.setText("Światło:\n " + String.valueOf(light));
        }

        if (event.sensor.getType() == Sensor.TYPE_RELATIVE_HUMIDITY){
            float relative_humidity = event.values[0];
            humidityValues.setText("Wilgotność:\n "+String.valueOf(relative_humidity));
        }
    }

    @Override
    protected void onResume() {
        // Register a listener for the sensor.
        super.onResume();
        sensorManager.registerListener(this, thermometer, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager2.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager3.registerListener(this, humiditySensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        // Be sure to unregister the sensor when the activity pauses.
        super.onPause();
        sensorManager.unregisterListener(this, thermometer);
        sensorManager2.unregisterListener(this, lightSensor);
        sensorManager3.unregisterListener(this, humiditySensor);
    }


}