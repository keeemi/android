package com.example.algrytmeuklidesa;

import android.os.Bundle;
import android.text.Editable;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    TextView wyswietl;
    EditText liczba1;
    EditText liczba2;
    Button zapisz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Scanner scanner = new Scanner(System.in);


        wyswietl = findViewById(R.id.wyswietlacz);
        liczba1 = findViewById(R.id.pierwszaLiczba);
        liczba2 = findViewById(R.id.drugaLiczba);
        zapisz = findViewById(R.id.buttonZapisz);



        zapisz.setOnClickListener(e ->{
            int wartosc1 = Integer.parseInt(liczba1.getText().toString());
            int wartosc2 = Integer.parseInt(liczba2.getText().toString());
            funkcja(wartosc1,wartosc2);
        });


        /*
        int a =15;
        int b =33;
        int pomocnicza =0;

        while (a!=b){
            if (a>b){
                pomocnicza=a-b;
                a=pomocnicza;
            }
            else{
                pomocnicza=b-a;
                b=pomocnicza;
            }
        }

        wyswietl.setText("Największy wspólny dzielnik liczb: "+b);



        //int[] dzielniki = new int[100];
        ArrayList<Integer> dzielniki = new ArrayList<Integer>();

        for (int i=1; i<=a; i++){

            float dzielenie = (float) a/ (float) i;

            int dzielenieDwa = (int) dzielenie;

            int dzielnik;

            if (dzielenie==dzielenieDwa){
                dzielnik=dzielenieDwa;
                //dzielniki[i]= dzielnik;
                dzielniki.add(i);
            }

        }

        //String tablica = String.join(",", Arrays.toString(dzielniki));

        wyswietl.setText(dzielniki+"");



         */

    }
    void funkcja(int arg1, int arg2) {
        int pomocnicza =0;

        while (arg1!=arg2){
            if (arg1>arg2){
                pomocnicza=arg1-arg2;
                arg1=pomocnicza;
            }
            else{
                pomocnicza=arg2-arg1;
                arg2=pomocnicza;
            }
        }

        wyswietl.setText("Największy wspólny dzielnik liczb: "+arg2);
    }
}