package com.example.egzamin;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText email;
    EditText haslo;
    EditText powtorzHaslo;
    Button zatwierdz;
    TextView komunikat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        email = findViewById(R.id.editTextEmail);
        haslo = findViewById(R.id.editTextPasswordHaslo);
        powtorzHaslo = findViewById(R.id.editTextPasswordPowtorzHaslo);
        zatwierdz = findViewById(R.id.buttonZatwierdź);
        komunikat = findViewById(R.id.textViewKomunikat);

        komunikat.setText("Autor: Emilia Katta");

        zatwierdz.setOnClickListener(e->{
            String emailTekst = email.getText().toString();
            boolean czyEmailJestPoprawny = false;

            String haslo1 = haslo.getText().toString();
            String haslo2 = powtorzHaslo.getText().toString();
            boolean czyHaslaSaTakieSame = false;

            if (emailTekst.contains("@")){
                czyEmailJestPoprawny = true;
            }
            else{
                komunikat.setText("Nieprawidłowy adres e-mail");
                czyEmailJestPoprawny = false;
            }

            if (haslo1.equals(haslo2)){
                czyHaslaSaTakieSame = true;
            }
            else{
                komunikat.setText("Hasła się różnią");
                czyHaslaSaTakieSame = false;
            }

            if (czyEmailJestPoprawny==true && czyHaslaSaTakieSame==true){
                komunikat.setText("Witaj "+emailTekst);
            }

        });

    }
}