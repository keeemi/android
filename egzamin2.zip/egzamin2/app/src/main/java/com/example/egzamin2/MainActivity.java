package com.example.egzamin2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    TextView rozmiar;
    TextView cytat;
    SeekBar suwak;
    Button przycisk;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        rozmiar = findViewById(R.id.textViewRozmiar);
        cytat = findViewById(R.id.textViewCytat);
        suwak = findViewById(R.id.seekBarSuwak);
        przycisk = findViewById(R.id.buttonPrzycisk);

        cytat.setText("Dzień dobry");

        suwak.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                int wartoscSuwaka = suwak.getProgress();
                rozmiar.setText("Rozmiar: "+wartoscSuwaka);
                cytat.setTextSize(wartoscSuwaka);

            }
        });

        String[] tablica = {"Dzień dobry", "Good morning", "Buenos dias"};

        przycisk.setOnClickListener(e->{
            if (cytat.getText()==tablica[0]){
                cytat.setText(tablica[1]);
            }
            else if(cytat.getText()==tablica[1]){
                cytat.setText(tablica[2]);
            }
            else if(cytat.getText()==tablica[2]){
                cytat.setText(tablica[0]);
            }
        });

    }



}