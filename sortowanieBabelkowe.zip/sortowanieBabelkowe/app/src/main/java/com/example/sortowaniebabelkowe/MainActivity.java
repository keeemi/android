package com.example.sortowaniebabelkowe;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    TextView tekst;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tekst = findViewById(R.id.tekst);


        int[] tablica = {4, 12, 8, 9, 10, 2, 6};
        int[] tablica2 = new int[7];
        int nastepnyIndeks = 0;

        //petla przechodzi przez elementy tablicy.
        //Do zmiennej "poprzedniElement" przypisuje się wartość poprzedniej wartości zmiennej "i",
        //którą przejmowała przed wykonaniem pętli, która jest wykonywana teraz.
        //Do zmiennej "nastepnyElement" przypisuje się wartość następnej wartości zmiennej "i",
        //którą będzie przyjmować podczas wykonywania następnej pętli.



        for (int a = 1; a < tablica.length; a++) {
                for (int i = 0; i < tablica.length - a; i++) {
                    nastepnyIndeks = i+1;

                    //Jeśli wartość zmiennej "i" z tej pętli jest większa,
                    // niż wartość "i" z poprzedniej pętli
                    // to w tablicy2 jest tworzony element "i"
                    if (tablica[i] > tablica[nastepnyIndeks]) {
                        int aktualnaWartosc = tablica[i];
                        int nastepnaWartosc = tablica[nastepnyIndeks];
                        tablica[i] = nastepnaWartosc;
                        tablica[nastepnyIndeks] = aktualnaWartosc;
                    }
                    //jeśli wartość zmiennej "i" z tej pętli jest mniejsza.
                    //niż wartość "i" z poprzedniej pętli
                    //to w tablicy2 jest tworzony element
                    /*else if (tablica[i]<poprzedniElement){
                        tablica2[i] = i;
                    }*/


                }



        }

        String tab = String.join(",", Arrays.toString(tablica));
        tekst.setText(tab + "");
    }

}