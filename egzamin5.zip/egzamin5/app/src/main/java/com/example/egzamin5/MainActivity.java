package com.example.egzamin5;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button resetujWynik;
    Button rzucKoscmi;
    TextView wynikLosowania;
    TextView wynikGry;
    ImageView pierwszaKostka;
    ImageView drugaKostka;
    ImageView trzeciaKostka;
    ImageView czwartaKostka;
    ImageView piataKostka;
    ImageView szostaKostka;
    ArrayList<Number> liczby;
    int wynikCaly = 0;
    int wynikTeraz = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        resetujWynik = findViewById(R.id.buttonResetujWynik);
        rzucKoscmi = findViewById(R.id.buttonRzucKoscmi);
        wynikLosowania = findViewById(R.id.textViewWynik);
        wynikGry = findViewById(R.id.textViewWynikGry);
        pierwszaKostka = findViewById(R.id.imageViewPierwszaKostka);
        drugaKostka = findViewById(R.id.imageViewDrugaKostka);
        trzeciaKostka = findViewById(R.id.imageViewTrzeciaKostka);
        czwartaKostka = findViewById(R.id.imageViewCzwartaKostka);
        piataKostka = findViewById(R.id.imageViewPiataKostka);
        szostaKostka = findViewById(R.id.imageViewSzostaKostka);


        resetujWynik.setOnClickListener(e->{
            wynikCaly = 0;
            wynikTeraz = 0;
            wynikGry.setText("Wynik gry: "+wynikCaly);
            wynikLosowania.setText("Wynik tego losowania: "+wynikTeraz);
            pierwszaKostka.setImageResource(R.drawable.question);
            drugaKostka.setImageResource(R.drawable.question);
            trzeciaKostka.setImageResource(R.drawable.question);
            czwartaKostka.setImageResource(R.drawable.question);
            piataKostka.setImageResource(R.drawable.question);
            szostaKostka.setImageResource(R.drawable.question);
        });

        rzucKoscmi.setOnClickListener(e->{
            Random randomowaLiczba = new Random();
            liczby = new ArrayList<Number>();

            for (int i=0; i<6; i++){
                liczby.add(randomowaLiczba.nextInt(6)+1);
            }

            int liczbaOWartosci1 = 0;
            int liczbaOWartosci2 = 0;
            int liczbaOWartosci3 = 0;
            int liczbaOWartosci4 = 0;
            int liczbaOWartosci5 = 0;
            int liczbaOWartosci6 = 0;

            for (int a=0; a<6; a++){
                if ((int)liczby.get(a)==1){
                    liczbaOWartosci1+=1;
                }
                if ((int)liczby.get(a)==2){
                    liczbaOWartosci2+=1;
                }
                if ((int)liczby.get(a)==3){
                    liczbaOWartosci3+=1;
                }
                if ((int)liczby.get(a)==4){
                    liczbaOWartosci4+=1;
                }
                if ((int)liczby.get(a)==5){
                    liczbaOWartosci5+=1;
                }
                if ((int)liczby.get(a)==6){
                    liczbaOWartosci6+=1;
                }
            }

            wynikTeraz = 0;

            if(liczbaOWartosci1>=2){
                wynikTeraz+=liczbaOWartosci1*1;
            }
            if(liczbaOWartosci2>=2){
                wynikTeraz+=liczbaOWartosci2*2;
            }
            if(liczbaOWartosci3>=2){
                wynikTeraz+=liczbaOWartosci3*3;
            }
            if(liczbaOWartosci4>=2){
                wynikTeraz+=liczbaOWartosci4*4;
            }
            if(liczbaOWartosci5>=2){
                wynikTeraz+=liczbaOWartosci5*5;
            }
            if(liczbaOWartosci6>=2){
                wynikTeraz+=liczbaOWartosci6*6;
            }


            wynikCaly += wynikTeraz;


            wynikLosowania.setText(/*"Wylosowane liczby:"+liczby.toString()+"\nwartosc1: "+liczbaOWartosci1+"\nwartosc2: "+liczbaOWartosci2+"\nwartosc3: "+liczbaOWartosci3+"\nwartosc4: "+liczbaOWartosci4+"\nwartosc5: "+liczbaOWartosci5+"\nwartosc6: "+liczbaOWartosci6+*/"Wynik tego losowania: "+wynikTeraz);
            wynikGry.setText("Wynik gry: "+wynikCaly);


            for (int j=0; j< liczby.size(); j++){

                if (j==0) {
                    ustawKostke(j,pierwszaKostka);
                }
                else if(j==1){
                    ustawKostke(j,drugaKostka);
                }
                else if(j==2){
                    ustawKostke(j,trzeciaKostka);
                }
                else if(j==3){
                    ustawKostke(j,czwartaKostka);
                }
                else if(j==4){
                    ustawKostke(j,piataKostka);
                }
                else if(j==5){
                    ustawKostke(j,szostaKostka);
                }
            }




        });
    }

    public void ustawKostke(int j,ImageView kostka){
        if ((int)liczby.get(j)==1){
            kostka.setImageResource(R.drawable.k1);
        }
        else if((int)liczby.get(j)==2){
            kostka.setImageResource(R.drawable.k2);
        }
        else if((int)liczby.get(j)==3){
            kostka.setImageResource(R.drawable.k3);
        }
        else if((int)liczby.get(j)==4){
            kostka.setImageResource(R.drawable.k4);
        }
        else if((int)liczby.get(j)==5){
            kostka.setImageResource(R.drawable.k5);
        }
        else if((int)liczby.get(j)==6){
            kostka.setImageResource(R.drawable.k6);
        }
    }
}